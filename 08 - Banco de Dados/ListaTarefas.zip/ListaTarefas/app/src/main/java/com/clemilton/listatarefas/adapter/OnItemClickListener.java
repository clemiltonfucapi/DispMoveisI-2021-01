package com.clemilton.listatarefas.adapter;


public interface OnItemClickListener {
    void onItemClick(int position);
}
